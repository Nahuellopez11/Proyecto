namespace Program;

public enum EstadoEspecial
{
    Normal,
    Dormido,
    Paralizado,
    Envenenado,
    Quemado
}
