using NUnit.Framework;
using System;
using System.Collections.Generic;

namespace Program.Tests
{
    [TestFixture]
    public class InicializacionBatallaContraJugadorTests
    {
        private InicializacionBatallaContraJugador _batalla;
        private ElegirPokemon _elegirPokemon;
        private Jugador _jugador1;
        private Jugador _jugador2;

        [SetUp]
        public void SetUp()
        {
            // Crear listas de Pokémon para los jugadores
            var listaPokemonJugador1 = new List<IPokemon>
            {
                new Pokemon("Pikachu", TipoPokemon.Electrico, 100),
                new Pokemon("Charmander", TipoPokemon.Fuego, 80)
            };

            var listaPokemonJugador2 = new List<IPokemon>
            {
                new Pokemon("Squirtle", TipoPokemon.Agua, 90),
                new Pokemon("Bulbasaur", TipoPokemon.Planta, 85)
            };

            _jugador1 = new Jugador(listaPokemonJugador1);
            _jugador2 = new Jugador(listaPokemonJugador2);

            // Crear el objeto ElegirPokemon con los equipos iniciales
            _elegirPokemon = new ElegirPokemon();
            _elegirPokemon.catalogo = new CatalogoPokemones(listaPokemonJugador1, listaPokemonJugador2);

            // Inicializar la batalla
            _batalla = new InicializacionBatallaContraJugador(_elegirPokemon);
        }

        [Test]
        public void Constructor_DeberiaInicializarJugadoresCorrectamente()
        {
            Assert.DoesNotThrow(() => new InicializacionBatallaContraJugador(_elegirPokemon));
        }

        [Test]
        public void Constructor_DeberiaLanzarExcepcion_CuandoElegirPokemonEsNulo()
        {
            Assert.Throws<ArgumentNullException>(() =>
                new InicializacionBatallaContraJugador(null));
        }

        [Test]
        public void LogicaJuego_DeberiaAlternarTurnosCorrectamente()
        {
            // Inicializamos un Pokémon activo para ambos jugadores
            IPokemon pokemonActivoJugador1 = _jugador1.ElegirPrimerPokemon();
            IPokemon pokemonActivoJugador2 = _jugador2.ElegirPrimerPokemon();

            // Simular un turno del jugador 1 atacando
            pokemonActivoJugador1.Vida -= 30; // Reducir la vida del oponente en un ataque
            Assert.AreEqual(70, pokemonActivoJugador1.Vida);

            // Verificar cambio de turno después de un ataque
            IPokemon nuevoPokemon = Utilities.CambiarPokemonJugador(_jugador1, pokemonActivoJugador1);
            Assert.AreNotSame(pokemonActivoJugador1, nuevoPokemon);
        }

        [Test]
        public void LogicaJuego_DeberiaTerminarElJuego_CuandoUnJugadorPierdeTodosLosPokemon()
        {
            // Reducir toda la vida de los Pokémon del jugador 1
            foreach (var pokemon in _jugador1.ListaDePokemones)
            {
                pokemon.Vida = 0;
            }

            // Verificar fin de la batalla
            bool juegoTerminado = Utilities.VerificarFinBatalla(_jugador1.ListaDePokemones);
            Assert.IsTrue(juegoTerminado, "La batalla no terminó aunque todos los Pokémon están debilitados.");
        }

        [Test]
        public void CambiarPokemon_DeberiaCambiarPokemonActivo()
        {
            IPokemon pokemonInicial = _jugador1.ElegirPrimerPokemon();
            Assert.AreEqual("Pikachu", pokemonInicial.Nombre);

            IPokemon nuevoPokemon = Utilities.CambiarPokemonJugador(_jugador1, pokemonInicial);
            Assert.AreNotEqual(pokemonInicial, nuevoPokemon);
            Assert.IsTrue(nuevoPokemon.Vida > 0, "El nuevo Pokémon seleccionado debería tener vida.");
        }
    }

    // Clases necesarias para simular el entorno
    public class Pokemon : IPokemon
    {
        public string Nombre { get; }
        public TipoPokemon Tipo { get; }
        public double Vida { get; set; }

        public Pokemon(string nombre, TipoPokemon tipo, double vida)
        {
            Nombre = nombre;
            Tipo = tipo;
            Vida = vida;
        }

        public void Accept(IVisitorPoke visitorPoke)
        {
            // Implementación vacía para cumplir con la interfaz
        }
    }

    public enum TipoPokemon
    {
        Fuego,
        Agua,
        Planta,
        Electrico
    }
}
