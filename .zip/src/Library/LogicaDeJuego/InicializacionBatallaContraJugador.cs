using NUnit.Framework;
using Moq;
using Program; // Reemplaza con el namespace correspondiente
using System;
using System.Collections.Generic;

namespace Tests
{
    [TestFixture]
    public class InicializacionBatallaContraJugadorTests
    {
        private Mock<ElegirPokemon> mockElegirPokemon;
        private List<IPokemon> equipoJugador1;
        private List<IPokemon> equipoJugador2;

        [SetUp]
        public void SetUp()
        {
            // Inicialización de datos de prueba
            equipoJugador1 = new List<IPokemon>
            {
                new Mock<IPokemon>().Object,
                new Mock<IPokemon>().Object
            };

            equipoJugador2 = new List<IPokemon>
            {
                new Mock<IPokemon>().Object,
                new Mock<IPokemon>().Object
            };

            // Mock de ElegirPokemon
            mockElegirPokemon = new Mock<ElegirPokemon>();
            mockElegirPokemon.Setup(m => m.DevolverListajugador1()).Returns(equipoJugador1);
            mockElegirPokemon.Setup(m => m.DevolverListajugador2()).Returns(equipoJugador2);
        }

        [Test]
        public void Constructor_ValidData_CreatesPlayers()
        {
            // Act
            var batalla = new InicializacionBatallaContraJugador(mockElegirPokemon.Object);

            // Assert
            Assert.IsNotNull(batalla);
        }

        [Test]
        public void Constructor_NullElegirPokemon_ThrowsArgumentNullException()
        {
            // Arrange
            ElegirPokemon elegirPokemonNull = null;

            // Act & Assert
            var ex = Assert.Throws<ArgumentNullException>(() =>
                new InicializacionBatallaContraJugador(elegirPokemonNull));
            Assert.AreEqual("El objeto ElegirPokemon no puede ser null. (Parameter 'elegirPokemon')", ex.Message);
        }

        [Test]
        public void Constructor_EmptyTeam_ThrowsInvalidOperationException()
        {
            // Arrange
            mockElegirPokemon.Setup(m => m.DevolverListajugador1()).Returns(new List<IPokemon>());
            mockElegirPokemon.Setup(m => m.DevolverListajugador2()).Returns(new List<IPokemon>());

            // Act & Assert
            var ex = Assert.Throws<InvalidOperationException>(() =>
                new InicializacionBatallaContraJugador(mockElegirPokemon.Object));
            Assert.AreEqual("El equipo del Jugador 1 está vacío.", ex.Message);
        }

        [Test]
        public void LogicaJuego_ValidPlayers_ExecutesGameLoop()
        {
            // Arrange
            var mockPokemon1 = new Mock<IPokemon>();
            var mockPokemon2 = new Mock<IPokemon>();
            mockPokemon1.Setup(p => p.Vida).Returns(100);
            mockPokemon2.Setup(p => p.Vida).Returns(100);
            mockPokemon1.Setup(p => p.Nombre).Returns("Pikachu");
            mockPokemon2.Setup(p => p.Nombre).Returns("Charmander");

            equipoJugador1 = new List<IPokemon> { mockPokemon1.Object };
            equipoJugador2 = new List<IPokemon> { mockPokemon2.Object };

            mockElegirPokemon.Setup(m => m.DevolverListajugador1()).Returns(equipoJugador1);
            mockElegirPokemon.Setup(m => m.DevolverListajugador2()).Returns(equipoJugador2);

            var batalla = new InicializacionBatallaContraJugador(mockElegirPokemon.Object);

            // Act
            // Simulamos que el flujo del juego funciona sin excepciones.
            Assert.DoesNotThrow(() => batalla.LogicaJuego());
        }
    }
}
