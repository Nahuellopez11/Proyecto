var searchData=
[
  ['jugador_0',['Jugador',['../class_program_1_1_jugador.html#a92951088758041ec1d61e71d7f09fba5',1,'Program::Jugador']]]
];
