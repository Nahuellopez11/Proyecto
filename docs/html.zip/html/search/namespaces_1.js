var searchData=
[
  ['program_0',['Program',['../namespace_program.html',1,'']]],
  ['program_3a_3adiscord_1',['Discord',['../namespace_program_1_1_discord.html',1,'Program']]],
  ['program_3a_3adiscord_3a_3acommands_2',['Commands',['../namespace_program_1_1_discord_1_1_commands.html',1,'Program::Discord']]],
  ['program_3a_3atests_3',['Tests',['../namespace_program_1_1_tests.html',1,'Program']]]
];
