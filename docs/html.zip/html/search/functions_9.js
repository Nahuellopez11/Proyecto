var searchData=
[
  ['logicajuego_0',['LogicaJuego',['../class_program_1_1_inicializacion_batalla_contra_jugador.html#afa81c5c0d085fe8bf0a4c5472a292a3b',1,'Program::InicializacionBatallaContraJugador']]]
];
