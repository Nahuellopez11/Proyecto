var searchData=
[
  ['ibot_0',['IBot',['../interface_ucu_1_1_poo_1_1_discord_bot_1_1_services_1_1_i_bot.html',1,'Ucu::Poo::DiscordBot::Services']]],
  ['id_1',['Id',['../interface_program_1_1_i_jugador.html#a5e442a4991e0a6bf56eb3be9312d40fa',1,'Program.IJugador.Id'],['../class_program_1_1_jugador.html#a4442f177a21e0423142d442325c3e15c',1,'Program.Jugador.Id']]],
  ['ihabilidadespokemon_2',['IHabilidadesPokemon',['../interface_program_1_1_i_habilidades_pokemon.html',1,'Program']]],
  ['iitem_3',['IItem',['../interface_program_1_1_i_item.html',1,'Program']]],
  ['ijugador_4',['IJugador',['../interface_program_1_1_i_jugador.html',1,'Program']]],
  ['inicializacionbatallacontrajugador_5',['InicializacionBatallaContraJugador',['../class_program_1_1_inicializacion_batalla_contra_jugador.html',1,'Program.InicializacionBatallaContraJugador'],['../class_program_1_1_inicializacion_batalla_contra_jugador.html#ac64ed22da6fd38c82356c39ed1eab398',1,'Program.InicializacionBatallaContraJugador.InicializacionBatallaContraJugador()']]],
  ['instance_6',['Instance',['../class_ucu_1_1_poo_1_1_discord_bot_1_1_domain_1_1_conector_de_clases.html#a29291e76687a1618e9f1770c91893346',1,'Ucu::Poo::DiscordBot::Domain::ConectorDeClases']]],
  ['ipokemon_7',['IPokemon',['../interface_program_1_1_i_pokemon.html',1,'Program']]],
  ['items_8',['Items',['../class_program_1_1_jugador.html#a4899af31cf107059b9ff62e8127ce201',1,'Program::Jugador']]],
  ['itemtests_9',['ItemTests',['../class_library_1_1_tests_1_1_item_tests.html',1,'Library::Tests']]],
  ['ivisitorpoke_10',['IVisitorPoke',['../interface_program_1_1_i_visitor_poke.html',1,'Program']]]
];
