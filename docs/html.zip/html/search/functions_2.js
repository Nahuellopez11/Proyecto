var searchData=
[
  ['calculardaño_0',['CalcularDaño',['../class_program_1_1_ataque.html#a1373e49eac92b77dfcf510d1ed9b1eea',1,'Program.Ataque.CalcularDaño()'],['../class_program_1_1_ataque_especial.html#a38ffbba90c000bd3b0664eb0178dcb9c',1,'Program.AtaqueEspecial.CalcularDaño()']]],
  ['catalogopokemones_1',['CatalogoPokemones',['../class_program_1_1_catalogo_pokemones.html#a7d7016c2d0737ffa1245715fc2266b71',1,'Program::CatalogoPokemones']]],
  ['crearpokemon_2',['CrearPokemon',['../class_program_1_1_catalogo_pokemones.html#a854c5e231d665575c6dbc4fac9bb18c9',1,'Program::CatalogoPokemones']]],
  ['curarestados_3',['CurarEstados',['../class_program_1_1_pokemon.html#a032a2e43f395333f969dcafaae8e83d3',1,'Program::Pokemon']]]
];
