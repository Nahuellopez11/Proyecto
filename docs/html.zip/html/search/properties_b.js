var searchData=
[
  ['valorataque_0',['ValorAtaque',['../interface_program_1_1_i_habilidades_pokemon.html#a05eca072ac7209f523083336f1725094',1,'Program.IHabilidadesPokemon.ValorAtaque'],['../class_program_1_1_ataque.html#a397fb511fd88167b6f6ae241b0ef0f83',1,'Program.Ataque.ValorAtaque']]],
  ['vida_1',['Vida',['../interface_program_1_1_i_pokemon.html#a0769d065a7abd72e91de84a1ef673b0d',1,'Program.IPokemon.Vida'],['../class_program_1_1_pokemon.html#ab3e9253a2ccae2850ed72691a9c0742a',1,'Program.Pokemon.Vida']]],
  ['vidainicial_2',['VidaInicial',['../class_program_1_1_pokemon.html#a06ff32dbfad6b43e9ff14ae0133b5f32',1,'Program::Pokemon']]]
];
