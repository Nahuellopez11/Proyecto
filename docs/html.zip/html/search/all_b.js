var searchData=
[
  ['nombre_0',['Nombre',['../interface_program_1_1_i_item.html#ad5f4e7c4c8664e57dc4f21044ad1c049',1,'Program.IItem.Nombre'],['../class_program_1_1_revivir.html#ab6c54b0139005e4e2349be3ca63762ab',1,'Program.Revivir.Nombre'],['../class_program_1_1_super_pocion.html#a7db429fe2bf73085645eb9b034181390',1,'Program.SuperPocion.Nombre'],['../interface_program_1_1_i_pokemon.html#a411f5dd18658ba06ff28a9ebdcc93421',1,'Program.IPokemon.Nombre'],['../class_program_1_1_pokemon.html#ad7a4b713bb74344d9554d7f2ba1030d7',1,'Program.Pokemon.Nombre'],['../class_program_1_1_tests_1_1_super_pocion.html#ad205b55fbd0a9c574bc041a0d8a67449',1,'Program.Tests.SuperPocion.Nombre']]],
  ['nombrehabilidad_1',['NombreHabilidad',['../interface_program_1_1_i_habilidades_pokemon.html#a29749f9a9620c212a0e989f6afae8a59',1,'Program.IHabilidadesPokemon.NombreHabilidad'],['../class_program_1_1_ataque.html#a497076808f0b5d712c0049b695b6e459',1,'Program.Ataque.NombreHabilidad']]]
];
