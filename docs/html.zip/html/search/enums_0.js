var searchData=
[
  ['tipopokemon_0',['TipoPokemon',['../namespace_program.html#a38f830971c7575cd1ac4f48a7546e5b0',1,'Program']]]
];
