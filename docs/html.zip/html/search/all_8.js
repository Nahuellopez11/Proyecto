var searchData=
[
  ['joincommand_0',['JoinCommand',['../class_program_1_1_discord_1_1_commands_1_1_join_command.html',1,'Program::Discord::Commands']]],
  ['jugador_1',['Jugador',['../class_program_1_1_jugador.html',1,'Program.Jugador'],['../class_program_1_1_jugador.html#a92951088758041ec1d61e71d7f09fba5',1,'Program.Jugador.Jugador()']]]
];
