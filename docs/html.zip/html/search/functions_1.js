var searchData=
[
  ['battle_0',['Battle',['../class_ucu_1_1_poo_1_1_discord_bot_1_1_domain_1_1_battle.html#a27068b3d3449693ee014f76a8711bc97',1,'Ucu::Poo::DiscordBot::Domain::Battle']]]
];
