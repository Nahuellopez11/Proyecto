var searchData=
[
  ['efectoestado_0',['EfectoEstado',['../class_program_1_1_ataque_especial.html#aeefd3bbe4677611e2cecf56a4b451a41',1,'Program::AtaqueEspecial']]],
  ['equipo_1',['Equipo',['../class_program_1_1_seleccion_pokes_visitor_poke.html#a1601b2fb1069635ed2b13d729602d6df',1,'Program.SeleccionPokesVisitorPoke.Equipo'],['../interface_program_1_1_i_visitor_poke.html#af6cc6db95449e6dc5a4a608839a54143',1,'Program.IVisitorPoke.Equipo']]],
  ['estadoactual_2',['EstadoActual',['../class_program_1_1_pokemon.html#a5ecff14ea3079bab0068bbdb35b1576f',1,'Program::Pokemon']]]
];
