var searchData=
[
  ['findtrainerbydisplayname_0',['FindTrainerByDisplayName',['../class_ucu_1_1_poo_1_1_discord_bot_1_1_domain_1_1_waiting_list.html#acc2e4a01aae29f639187155b8cb61cc2',1,'Ucu::Poo::DiscordBot::Domain::WaitingList']]]
];
