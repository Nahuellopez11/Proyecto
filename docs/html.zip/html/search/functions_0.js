var searchData=
[
  ['accept_0',['Accept',['../interface_program_1_1_i_pokemon.html#a75ecef174fe49cafb2061a75313be1fe',1,'Program.IPokemon.Accept()'],['../class_program_1_1_pokemon.html#abd489405b1e43394247cd4a73f19ceed',1,'Program.Pokemon.Accept()']]],
  ['addbattle_1',['AddBattle',['../class_ucu_1_1_poo_1_1_discord_bot_1_1_domain_1_1_battles_list.html#a0296d732f53091db728b8a825e52e16c',1,'Ucu::Poo::DiscordBot::Domain::BattlesList']]],
  ['addtrainer_2',['AddTrainer',['../class_ucu_1_1_poo_1_1_discord_bot_1_1_domain_1_1_waiting_list.html#ae678a5933c810f3bf198ba5fdf22509b',1,'Ucu::Poo::DiscordBot::Domain::WaitingList']]],
  ['addtrainertowaitinglist_3',['AddTrainerToWaitingList',['../class_ucu_1_1_poo_1_1_discord_bot_1_1_domain_1_1_conector_de_clases.html#afb2235c61eb7690cf4af02614c6f8db0',1,'Ucu::Poo::DiscordBot::Domain::ConectorDeClases']]],
  ['agregarpokemonescatalogo_4',['AgregarPokemonesCatalogo',['../class_program_1_1_catalogo_pokemones.html#af92a2a5c18b9f699dde9029ab2f6a464',1,'Program::CatalogoPokemones']]],
  ['aplicarefectoestado_5',['AplicarEfectoEstado',['../class_program_1_1_pokemon.html#a99e54842fc4067d138aadb011f71179c',1,'Program::Pokemon']]],
  ['aplicarefectosfinturno_6',['AplicarEfectosFinTurno',['../class_program_1_1_pokemon.html#acd9e6121406b62e49b66b0bf2086a714',1,'Program::Pokemon']]],
  ['aprenderataque_7',['AprenderAtaque',['../class_program_1_1_pokemon.html#a657340efa2fcc53fe981016bee5c108e',1,'Program::Pokemon']]],
  ['ataque_8',['Ataque',['../class_program_1_1_ataque.html#a2f4aa5889b394b9e52e79fc41f931352',1,'Program::Ataque']]],
  ['ataqueespecial_9',['AtaqueEspecial',['../class_program_1_1_ataque_especial.html#a5888673e2e34c58e53a7ba201310d865',1,'Program::AtaqueEspecial']]]
];
