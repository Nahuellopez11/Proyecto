var searchData=
[
  ['listadepokemones_0',['ListaDePokemones',['../interface_program_1_1_i_jugador.html#aa70e68cd0c189b4e1e6db93ee4f585a4',1,'Program.IJugador.ListaDePokemones'],['../class_program_1_1_jugador.html#a5325e0a095ea3377704627fcf2c4d48e',1,'Program.Jugador.ListaDePokemones']]]
];
