var searchData=
[
  ['catalogopokemones_0',['CatalogoPokemones',['../class_program_1_1_catalogo_pokemones.html',1,'Program']]],
  ['conectordeclases_1',['ConectorDeClases',['../class_ucu_1_1_poo_1_1_discord_bot_1_1_domain_1_1_conector_de_clases.html',1,'Ucu::Poo::DiscordBot::Domain']]]
];
