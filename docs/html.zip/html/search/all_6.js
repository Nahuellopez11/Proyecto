var searchData=
[
  ['getalltrainerswaiting_0',['GetAllTrainersWaiting',['../class_ucu_1_1_poo_1_1_discord_bot_1_1_domain_1_1_conector_de_clases.html#adf24437e78fb39b4103364233737c270',1,'Ucu::Poo::DiscordBot::Domain::ConectorDeClases']]],
  ['getanyonewaiting_1',['GetAnyoneWaiting',['../class_ucu_1_1_poo_1_1_discord_bot_1_1_domain_1_1_waiting_list.html#af24b84ca7b9189022ad6c4114d515e6e',1,'Ucu::Poo::DiscordBot::Domain::WaitingList']]]
];
