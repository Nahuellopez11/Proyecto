var searchData=
[
  ['tablaefectividad_0',['TablaEfectividad',['../class_program_1_1_tabla_efectividad.html',1,'Program']]],
  ['tipo_1',['Tipo',['../class_program_1_1_tipo.html',1,'Program']]]
];
