var searchData=
[
  ['usar_0',['Usar',['../interface_program_1_1_i_item.html#a02ea311e64b9ad746ebc9591a04e99d5',1,'Program.IItem.Usar()'],['../class_program_1_1_revivir.html#a4548d3db1643b55970d250184481e20d',1,'Program.Revivir.Usar()'],['../class_program_1_1_super_pocion.html#a9f2e5d531a2f57323a5b34e870bfd0a9',1,'Program.SuperPocion.Usar()'],['../class_program_1_1_tests_1_1_super_pocion.html#a7e00f0367331ff021352dc0823a4ad8f',1,'Program.Tests.SuperPocion.Usar()']]]
];
