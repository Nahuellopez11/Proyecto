var searchData=
[
  ['tablaefectividad_0',['TablaEfectividad',['../class_program_1_1_tabla_efectividad.html',1,'Program']]],
  ['tests_1',['Tests',['../class_library_1_1_test_1_1_tests.html',1,'Library::Test']]],
  ['trainer_2',['Trainer',['../class_ucu_1_1_poo_1_1_discord_bot_1_1_domain_1_1_trainer.html',1,'Ucu::Poo::DiscordBot::Domain']]]
];
