var searchData=
[
  ['jugador_0',['Jugador',['../class_program_1_1_jugador.html',1,'Program']]]
];
