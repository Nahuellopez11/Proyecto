var searchData=
[
  ['obtenerefectividad_0',['ObtenerEfectividad',['../class_program_1_1_tabla_efectividad.html#a5bf1e57bbd28b1b6387d22ec788ee7fe',1,'Program::TablaEfectividad']]],
  ['obtenerequipoactual_1',['ObtenerEquipoActual',['../class_program_1_1_catalogo_pokemones.html#a417e1ff5a431b48afa0b68bdd9ed88ff',1,'Program::CatalogoPokemones']]],
  ['obtenerequipoactual2_2',['ObtenerEquipoActual2',['../class_program_1_1_catalogo_pokemones.html#ae196eb71e9999a17704db717cb6d2157',1,'Program::CatalogoPokemones']]]
];
