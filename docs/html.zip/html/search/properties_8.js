var searchData=
[
  ['player1_0',['Player1',['../class_ucu_1_1_poo_1_1_discord_bot_1_1_domain_1_1_battle.html#a42dd33da3e0267f1376449dcabe15eb4',1,'Ucu::Poo::DiscordBot::Domain::Battle']]],
  ['player2_1',['Player2',['../class_ucu_1_1_poo_1_1_discord_bot_1_1_domain_1_1_battle.html#a58120eb272d8f494e142a68b2c53d7eb',1,'Ucu::Poo::DiscordBot::Domain::Battle']]],
  ['precision_2',['Precision',['../class_program_1_1_ataque.html#a6ba8c16633d316801c10529e7990a321',1,'Program::Ataque']]]
];
