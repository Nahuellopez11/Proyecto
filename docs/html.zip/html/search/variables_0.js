var searchData=
[
  ['catalogo_0',['catalogo',['../class_program_1_1_elegir_pokemon.html#ae2b7b95b05ef9f61f9c6304db0916673',1,'Program::ElegirPokemon']]]
];
