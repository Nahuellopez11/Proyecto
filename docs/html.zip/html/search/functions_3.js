var searchData=
[
  ['devolverlistajugador1_0',['DevolverListajugador1',['../class_program_1_1_elegir_pokemon.html#a32074e0d90654573d7081bf7acb5b936',1,'Program::ElegirPokemon']]],
  ['devolverlistajugador2_1',['DevolverListajugador2',['../class_program_1_1_elegir_pokemon.html#a60568ddc1c581cd564207804d4841c33',1,'Program::ElegirPokemon']]]
];
