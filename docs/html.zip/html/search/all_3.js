var searchData=
[
  ['ihabilidadespokemon_0',['IHabilidadesPokemon',['../interface_program_1_1_i_habilidades_pokemon.html',1,'Program']]],
  ['iitem_1',['IItem',['../interface_program_1_1_i_item.html',1,'Program']]],
  ['ijugadores_2',['IJugadores',['../interface_program_1_1_i_jugadores.html',1,'Program']]],
  ['incializacionbatalla_3',['IncializacionBatalla',['../class_program_1_1_incializacion_batalla.html',1,'Program']]],
  ['ipokemones_4',['IPokemones',['../interface_program_1_1_i_pokemones.html',1,'Program']]],
  ['ivisitorpoke_5',['IVisitorPoke',['../interface_program_1_1_i_visitor_poke.html',1,'Program']]]
];
