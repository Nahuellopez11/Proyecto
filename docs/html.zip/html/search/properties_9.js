var searchData=
[
  ['tipo_0',['Tipo',['../interface_program_1_1_i_pokemon.html#a115048d2b4c464128ddfd1914ee1ad70',1,'Program.IPokemon.Tipo'],['../class_program_1_1_pokemon.html#a48e088cab042442479fec53d82620c1b',1,'Program.Pokemon.Tipo'],['../class_program_1_1_ataque.html#a15e8b6a6dd35aedfa116a72179e40647',1,'Program.Ataque.Tipo']]]
];
