var searchData=
[
  ['dañobase_0',['DañoBase',['../class_program_1_1_ataque.html#a3db8916b6c6c614c65f576598bb34299',1,'Program::Ataque']]],
  ['displayname_1',['DisplayName',['../class_ucu_1_1_poo_1_1_discord_bot_1_1_domain_1_1_trainer.html#aa192a6e967ada36623c47e8ba25abfa1',1,'Ucu::Poo::DiscordBot::Domain::Trainer']]]
];
