var searchData=
[
  ['valorataque_0',['ValorAtaque',['../interface_program_1_1_i_habilidades_pokemon.html#a05eca072ac7209f523083336f1725094',1,'Program.IHabilidadesPokemon.ValorAtaque'],['../class_program_1_1_ataque.html#a397fb511fd88167b6f6ae241b0ef0f83',1,'Program.Ataque.ValorAtaque']]],
  ['vida_1',['Vida',['../interface_program_1_1_i_pokemon.html#a0769d065a7abd72e91de84a1ef673b0d',1,'Program.IPokemon.Vida'],['../class_program_1_1_pokemon.html#ab3e9253a2ccae2850ed72691a9c0742a',1,'Program.Pokemon.Vida']]],
  ['vidainicial_2',['VidaInicial',['../class_program_1_1_pokemon.html#a06ff32dbfad6b43e9ff14ae0133b5f32',1,'Program::Pokemon']]],
  ['visit_3',['Visit',['../class_program_1_1_seleccion_pokes_visitor_poke.html#a88e46606a72246475a05b299446194c1',1,'Program::SeleccionPokesVisitorPoke']]],
  ['visitpokemon_4',['VisitPokemon',['../class_program_1_1_seleccion_pokes_visitor_poke.html#a95c601ad38d73505948b66f75aefe916',1,'Program.SeleccionPokesVisitorPoke.VisitPokemon()'],['../interface_program_1_1_i_visitor_poke.html#aad29be0daab18bdf25b0b1842b9892e7',1,'Program.IVisitorPoke.VisitPokemon()']]]
];
