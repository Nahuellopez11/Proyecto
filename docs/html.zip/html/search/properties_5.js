var searchData=
[
  ['id_0',['Id',['../interface_program_1_1_i_jugador.html#a5e442a4991e0a6bf56eb3be9312d40fa',1,'Program.IJugador.Id'],['../class_program_1_1_jugador.html#a4442f177a21e0423142d442325c3e15c',1,'Program.Jugador.Id']]],
  ['instance_1',['Instance',['../class_ucu_1_1_poo_1_1_discord_bot_1_1_domain_1_1_conector_de_clases.html#a29291e76687a1618e9f1770c91893346',1,'Ucu::Poo::DiscordBot::Domain::ConectorDeClases']]],
  ['items_2',['Items',['../class_program_1_1_jugador.html#a4899af31cf107059b9ff62e8127ce201',1,'Program::Jugador']]]
];
