var searchData=
[
  ['ataquesdisponibles_0',['AtaquesDisponibles',['../class_program_1_1_pokemon.html#a17cb1b460975e21fc9b7070704d5c0d6',1,'Program::Pokemon']]]
];
