var indexSectionsWithContent =
{
  0: "aceijlmprstu",
  1: "aceijmprstu",
  2: "lp"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces"
};

