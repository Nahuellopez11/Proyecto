var indexSectionsWithContent =
{
  0: "abcdefgijlmnoprstuvw",
  1: "abceijlprstuw",
  2: "lpu",
  3: "abcdefgijlmoprstuv",
  4: "cr",
  5: "t",
  6: "acdefilnptuv",
  7: "r"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "properties",
  7: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Functions",
  4: "Variables",
  5: "Enumerations",
  6: "Properties",
  7: "Pages"
};

