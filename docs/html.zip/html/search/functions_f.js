var searchData=
[
  ['trainer_0',['Trainer',['../class_ucu_1_1_poo_1_1_discord_bot_1_1_domain_1_1_trainer.html#aed71dc889355e8a310a0607168e00cbf',1,'Ucu::Poo::DiscordBot::Domain::Trainer']]],
  ['traineriswaiting_1',['TrainerIsWaiting',['../class_ucu_1_1_poo_1_1_discord_bot_1_1_domain_1_1_conector_de_clases.html#aec18a636abc365834d666ec7ccf15ee0',1,'Ucu::Poo::DiscordBot::Domain::ConectorDeClases']]]
];
