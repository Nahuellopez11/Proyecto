var searchData=
[
  ['seleccionpokesvisitorpoke_0',['SeleccionPokesVisitorPoke',['../class_program_1_1_seleccion_pokes_visitor_poke.html',1,'Program']]],
  ['sistemacombate_1',['SistemaCombate',['../class_program_1_1_sistema_combate.html',1,'Program']]],
  ['superpocion_2',['SuperPocion',['../class_program_1_1_super_pocion.html',1,'Program']]]
];
