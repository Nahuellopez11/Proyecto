var searchData=
[
  ['ataque_0',['Ataque',['../class_program_1_1_ataque.html',1,'Program']]],
  ['ataqueespecial_1',['AtaqueEspecial',['../class_program_1_1_ataque_especial.html',1,'Program']]],
  ['ataquestests_2',['AtaquesTests',['../class_library_1_1_tests_1_1_ataques_tests.html',1,'Library::Tests']]],
  ['ataquetests_3',['AtaqueTests',['../class_library_1_1_tests_1_1_ataque_tests.html',1,'Library::Tests']]]
];
