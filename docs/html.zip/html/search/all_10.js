var searchData=
[
  ['tablaefectividad_0',['TablaEfectividad',['../class_program_1_1_tabla_efectividad.html',1,'Program']]],
  ['tests_1',['Tests',['../class_library_1_1_test_1_1_tests.html',1,'Library::Test']]],
  ['tipo_2',['Tipo',['../interface_program_1_1_i_pokemon.html#a115048d2b4c464128ddfd1914ee1ad70',1,'Program.IPokemon.Tipo'],['../class_program_1_1_pokemon.html#a48e088cab042442479fec53d82620c1b',1,'Program.Pokemon.Tipo'],['../class_program_1_1_ataque.html#a15e8b6a6dd35aedfa116a72179e40647',1,'Program.Ataque.Tipo']]],
  ['tipopokemon_3',['TipoPokemon',['../namespace_program.html#a38f830971c7575cd1ac4f48a7546e5b0',1,'Program']]],
  ['trainer_4',['Trainer',['../class_ucu_1_1_poo_1_1_discord_bot_1_1_domain_1_1_trainer.html',1,'Ucu.Poo.DiscordBot.Domain.Trainer'],['../class_ucu_1_1_poo_1_1_discord_bot_1_1_domain_1_1_trainer.html#aed71dc889355e8a310a0607168e00cbf',1,'Ucu.Poo.DiscordBot.Domain.Trainer.Trainer()']]],
  ['traineriswaiting_5',['TrainerIsWaiting',['../class_ucu_1_1_poo_1_1_discord_bot_1_1_domain_1_1_conector_de_clases.html#aec18a636abc365834d666ec7ccf15ee0',1,'Ucu::Poo::DiscordBot::Domain::ConectorDeClases']]]
];
