var searchData=
[
  ['usosrestantes_0',['UsosRestantes',['../interface_program_1_1_i_item.html#af2c040adb7d4cf1733c014b9094ad4b8',1,'Program.IItem.UsosRestantes'],['../class_program_1_1_revivir.html#a764dae6ce5acb8392bb4121991e7a74f',1,'Program.Revivir.UsosRestantes'],['../class_program_1_1_super_pocion.html#a1c3eefe8db514de6b7963c28d20cea4f',1,'Program.SuperPocion.UsosRestantes'],['../class_program_1_1_tests_1_1_super_pocion.html#a1221b27624d8cfafa2ea2d3d9d103284',1,'Program.Tests.SuperPocion.UsosRestantes']]]
];
